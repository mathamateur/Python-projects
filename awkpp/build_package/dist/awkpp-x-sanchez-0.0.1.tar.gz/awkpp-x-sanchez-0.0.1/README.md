# AWK++ Package

This is a package for agregating data. It don't use a lor of RAM like pandas and may be convenient for researches and scientists. You can try some examples from `example` package to understand this library.
